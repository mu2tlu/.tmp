#include "../Command.hpp"

void ERROR(irc::Command *command) { (void)command; }
