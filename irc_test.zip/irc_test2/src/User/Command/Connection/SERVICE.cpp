#include "../Command.hpp"

void SERVICE(irc::Command *command) { (void)command; }
