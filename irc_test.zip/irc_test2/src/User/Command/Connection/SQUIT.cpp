#include "../Command.hpp"

void SQUIT(irc::Command *command) { (void)command; }
