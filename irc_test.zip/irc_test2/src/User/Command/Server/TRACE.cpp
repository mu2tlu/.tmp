#include "../Command.hpp"

void TRACE(irc::Command *command) { (void)command; }
