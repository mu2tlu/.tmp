#include "../Command.hpp"

void CONNECT(irc::Command *command) { (void)command; }
