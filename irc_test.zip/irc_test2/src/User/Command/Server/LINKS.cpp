#include "../Command.hpp"

void LINKS(irc::Command *command) { (void)command; }
