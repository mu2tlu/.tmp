#include "../Command.hpp"

void STATS(irc::Command *command) { (void)command; }
