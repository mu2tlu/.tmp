#include "../Command.hpp"

void SUMMON(irc::Command *command) { (void)command; }
