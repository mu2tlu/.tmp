#include "../Command.hpp"

void RESTART(irc::Command *command) { (void)command; }
