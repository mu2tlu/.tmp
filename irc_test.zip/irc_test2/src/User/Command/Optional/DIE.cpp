#include "../Command.hpp"

void DIE(irc::Command *command) { (void)command; }
