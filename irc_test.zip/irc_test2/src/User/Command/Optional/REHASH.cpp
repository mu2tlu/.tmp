#include "../Command.hpp"

void REHASH(irc::Command *command) { (void)command; }
