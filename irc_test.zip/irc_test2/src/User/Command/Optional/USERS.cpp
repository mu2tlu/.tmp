#include "../Command.hpp"

void USERS(irc::Command *command) { command->reply(446); }
