#include "../Command.hpp"

void SERVLIST(irc::Command *command) { (void)command; }
