#include "../Command.hpp"

void SQUERY(irc::Command *command) { (void)command; }
